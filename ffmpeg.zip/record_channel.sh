#!/bin/bash

SRC_ADDR=$1
DEST_DIR=$3
EXTENSION=$2

STREAM_ADDRESS="udp://$SRC_ADDR"

mkdir -p $DEST_DIR

xawtv

ffmpeg -t 10 -y -vd /dev/video0:freq=SRC_ADDR \
    -ad /dev/dsp -deinterlace \
    -r 25 -s 320×240 -f avi \
    -vcodec mpeg4 -b 800 -g 128 \
    -bf 2 -acodec mp3 -ab 64 \
    -ar 44100 -benchmark JACKAL_FFMPEG.avi

read
